"""Part A, Task 2: node_degree tool.

Calculates the degree (number of connections) of a given node in a graph.
Follow the tool contract in bootcamp/README.md.
"""
from graphkit.contract import check_node, error, get_graph, node_ref, ok


def run(store, graph_id: str, node: str = None, **params) -> dict:
    g, err = get_graph(store, graph_id)
    if err:
        return err

    if params:
        return error(f"Unknown parameter(s): {', '.join(params)}. node_degree takes graph_id and node.")

    err = check_node(g, node)
    if err:
        return err

    # TODO: Compute connections based on whether the graph is directed or undirected.
    # Return the result conforming to the tool contract with a clear summary sentence.
    raise NotImplementedError("Implement node connection counting in bootcamp/node_degree/tool.py")
